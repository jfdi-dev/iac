module.exports = {
  handler: (_event, _context) => {},
};
